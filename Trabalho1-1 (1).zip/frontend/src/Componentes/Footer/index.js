import "./index.css"

function Footer() {

    return(
        <footer className="App-footer">
            <h1>
                Pedro Henrique Vargas Navarro
            </h1>
        </footer>
    )
}

export default Footer;