import mysl from "mysql";

export const db = mysl.createConnection({
    host: "localhost",
    user: "root",
    password: "Vinger10@",
    database: "projetos"
});
db.connect((err) => {
    if (err) {
        console.error(err);
        return;
    }
    console.log("Connected successfully");
});