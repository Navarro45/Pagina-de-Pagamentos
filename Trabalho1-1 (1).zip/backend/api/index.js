import express from 'express';
import cors from 'cors';
import { db } from "./db.js";

const app = express();

app.use(cors({
    origin: 'http://localhost:3000',
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type'],
}));
app.use(express.json());

app.post('/pagamentos', (req, res) => {
    const { numCartao, Valor, destinatario, categoria } = req.body;
    const sql = 'INSERT INTO pagamentos (numCartao, Valor, destinatario, categoria) VALUES (?, ?, ?, ?)';
    db.query(sql, [numCartao, Valor, destinatario, categoria], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Pagamento criado com sucesso!' });
    });
});


app.get('/pagamentos', (req, res) => {
    db.query('SELECT * FROM pagamentos', (err, results) => {
        if (err) {
            console.error('Erro ao buscar dados:', err);
            return res.status(500).json({ message: 'Erro ao buscar dados' });
        }
        res.json(results);
    });
});


app.get('/pagamentos/:idPagamentos', (req, res) => {
    const { idPagamentos } = req.params;
    db.query('SELECT * FROM pagamentos WHERE idPagamentos = ?', [idPagamentos], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.length === 0) return res.status(404).json({ error: "Pagamento não encontrado" });
        res.json(results[0]);
    });
});


app.put('/pagamentos/:idPagamentos', (req, res) => {
    const { idPagamentos } = req.params;
    const { numCartao, Valor, destinatario, categoria } = req.body;

    db.query("UPDATE pagamentos SET numCartao = ?, Valor = ?, destinatario = ?, categoria = ? WHERE idPagamentos = ?", [numCartao,Valor,destinatario,categoria, idPagamentos], (err) => {
        if (err) return res.status(500).json({ error: "Erro ao atualizar pagamento" });
        res.json({ message: "Pagamento atualizado com sucesso!" });
    });
});


app.delete('/pagamentos/:idPagamentos', (req, res) => {
    const { idPagamentos } = req.params;

    db.query("DELETE FROM pagamentos WHERE idPagamentos = ?", [idPagamentos], (err) => {
        if (err) return res.status(500).json({ error: "Erro ao apagar o pagamento" });
        res.json({ message: "Pagamento apagado com sucesso!" });
    });
});


const PORT = 8800;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
